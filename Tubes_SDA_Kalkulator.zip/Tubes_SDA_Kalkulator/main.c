#include "Library/Kalkulator/kalkulator.h"

int main() {
	mainMenu();
}
